﻿using System;
using System.Collections.Generic;

namespace mentorapplication.Models
{
    public partial class Skills
    {
        public long Id { get; set; }
        public string Name { get; set; }
        public string Toc { get; set; }
        public long? Duration { get; set; }
        public string Prerequites { get; set; }
    }
}
