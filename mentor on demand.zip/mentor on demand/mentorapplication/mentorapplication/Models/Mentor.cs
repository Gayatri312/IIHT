﻿using System;
using System.Collections.Generic;

namespace mentorapplication.Models
{
    public partial class Mentor
    {
        public long Id { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
        public string LinkedinUrl { get; set; }
        public DateTime? RegDatetime { get; set; }
        public int? RegCode { get; set; }
        public int? YearsOfExperience { get; set; }
        public bool? Active { get; set; }
    }
}
