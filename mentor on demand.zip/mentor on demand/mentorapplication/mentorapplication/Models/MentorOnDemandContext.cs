﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace mentorapplication.Models
{
    public partial class MentorOnDemandContext : DbContext
    {
        public MentorOnDemandContext()
        {
        }

        public MentorOnDemandContext(DbContextOptions<MentorOnDemandContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Admin> Admin { get; set; }
        public virtual DbSet<Mentor> Mentor { get; set; }
        public virtual DbSet<MentorSkills> MentorSkills { get; set; }
        public virtual DbSet<Skills> Skills { get; set; }
        public virtual DbSet<Trainings> Trainings { get; set; }
        public virtual DbSet<Users> Users { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer("Server=(local);Database=MentorOnDemand;Trusted_Connection=True;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Admin>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.Password)
                    .HasColumnName("password")
                    .HasMaxLength(25)
                    .IsUnicode(false);

                entity.Property(e => e.Username)
                    .HasColumnName("username")
                    .HasMaxLength(25)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Mentor>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.Active).HasColumnName("active");

                entity.Property(e => e.LinkedinUrl)
                    .HasColumnName("linkedin_url")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.Password)
                    .HasColumnName("password")
                    .HasMaxLength(25)
                    .IsUnicode(false);

                entity.Property(e => e.RegCode).HasColumnName("reg_code");

                entity.Property(e => e.RegDatetime)
                    .HasColumnName("reg_datetime")
                    .HasColumnType("date");

                entity.Property(e => e.Username)
                    .HasColumnName("username")
                    .HasMaxLength(25)
                    .IsUnicode(false);

                entity.Property(e => e.YearsOfExperience).HasColumnName("years_of_experience");
            });

            modelBuilder.Entity<MentorSkills>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.FacilitiesOffered).HasColumnName("facilities_offered");

                entity.Property(e => e.Mid).HasColumnName("mid");

                entity.Property(e => e.SelfRating).HasColumnName("self_rating");

                entity.Property(e => e.Sid).HasColumnName("sid");

                entity.Property(e => e.TrainingsDelivered).HasColumnName("trainings_delivered");

                entity.Property(e => e.YearsOfExp).HasColumnName("years_of_exp");
            });

            modelBuilder.Entity<Skills>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.Duration).HasColumnName("duration");

                entity.Property(e => e.Name)
                    .HasColumnName("name")
                    .HasMaxLength(25)
                    .IsUnicode(false);

                entity.Property(e => e.Prerequites)
                    .HasColumnName("prerequites")
                    .HasMaxLength(25)
                    .IsUnicode(false);

                entity.Property(e => e.Toc)
                    .HasMaxLength(25)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Trainings>(entity =>
            {
                entity.ToTable("trainings");

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.AmountReceived).HasColumnName("amount_received");

                entity.Property(e => e.EndDate)
                    .HasColumnName("end_date")
                    .HasColumnType("date");

                entity.Property(e => e.MentorId).HasColumnName("mentor_id");

                entity.Property(e => e.Progress)
                    .HasColumnName("progress")
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.Rating).HasColumnName("rating");

                entity.Property(e => e.SkillId).HasColumnName("skill_id");

                entity.Property(e => e.StartDate)
                    .HasColumnName("start_date")
                    .HasColumnType("date");

                entity.Property(e => e.Status)
                    .HasColumnName("status")
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.UserId).HasColumnName("user_id");
            });

            modelBuilder.Entity<Users>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.Active).HasColumnName("active");

                entity.Property(e => e.ContactNumber).HasColumnName("contact_number");

                entity.Property(e => e.Firstname)
                    .HasColumnName("firstname")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.ForceResetPassword).HasColumnName("force_reset_password");

                entity.Property(e => e.Lastname)
                    .HasColumnName("lastname")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.Password)
                    .HasColumnName("password")
                    .HasMaxLength(25)
                    .IsUnicode(false);

                entity.Property(e => e.RegCode).HasColumnName("reg_code");

                entity.Property(e => e.RegDatetime)
                    .HasColumnName("reg_datetime")
                    .HasColumnType("date");

                entity.Property(e => e.Username)
                    .HasColumnName("username")
                    .HasMaxLength(25)
                    .IsUnicode(false);
            });
        }
    }
}
