﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using mentorapplication.Models;
using mentorapplication.Repository;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;


namespace mentorapplication.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        MentorOnDemandContext m = new MentorOnDemandContext();
        [HttpPost]
        [Route("InsertUserDetails")]
        public void InsertUserDetails([FromBody] Users user)
        {
            try
            {
                m.Database.ExecuteSqlCommand("USER_REGISTRATION '" + user.Username + "','" + user.Password + "','" + user.Firstname + "','" + user.Lastname +
                      "'," + user.ContactNumber + ",'" + user.RegDatetime + "','" + user.RegCode + "','" + user.ForceResetPassword + "'," + user.Active);
            }
            catch (Exception e)
            {
            }
            
        }

        [HttpGet]
        [Route("login/{name}/{pass}")]
        public Users login(string name, string pass)
        {
            
            List<Users> li = m.Users.ToList();

            foreach (Users user in li)
            {
                if (name == user.Username && pass == user.Password)
                {
                    return user;
                }
            }
            return null;


        }

        [HttpGet]
        [Route("loginmentor/{name}/{pass}")]
        public Mentor loginmentor(string name, string pass)
        {
            try
            {
                return m.Mentor.FromSql("USER_LOGINMENTOR'" + name + "','" + pass + "'").SingleOrDefault();
            }
            catch (Exception e)
            {
                return null;
            }

        }
        [HttpGet]
        [Route("loginadmin/{name}/{pass}")]
        public Admin loginadmin(string name, string pass)
        {
            try
            {
                return  m.Admin.FromSql("USER_LOGINADMIN'" + name + "','" + pass + "'").SingleOrDefault();
            }
            catch (Exception e)
            {
                return null;
            }

        }



        [HttpGet]
        [Route("GetMentorSkills")]
        public IEnumerable<MentorSkills> GetMentorSkills()
        {
            try
            {
                return m.MentorSkills.ToList();
            }
            catch (Exception e)
            {
                return null;
            }
        }
        [HttpPost]
        [Route("AddSkills")]
        public void addSkills([FromBody] MentorSkills ms)
        {
            try
            {
                m.MentorSkills.Add(ms);
            m.SaveChanges();

            }
            catch (Exception e)
            {
               
            }
        }


        [HttpGet]
        [Route("GetSkills")]
        public IEnumerable<Skills> GetSkills()
        {
            try
            {

                return m.Skills.FromSql("LIST_OF_TECHNOLOGIES");
            }
            catch (Exception e)
            {
                return null;
            }
        }
        [HttpGet]
        [Route("GetMentors")]
        public IEnumerable<Tempuser> GetMentors()
        {
             List<Mentor> li = m.Mentor.ToList();
            List<Tempuser> temp=new List<Tempuser>();
            foreach(Mentor me in li)
            {
                Tempuser t = new Tempuser();
                t.Id = me.Id;
                t.Username = me.Username;
                t.linkedinUrl = me.LinkedinUrl;
                t.reg_datetime = me.RegDatetime;
                t.regcode = me.RegCode;
                t.yearsOfExp = me.YearsOfExperience;
                t.active = me.Active;
                temp.Add(t);
            }
            return temp;

        }
    }
}