﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace mentorapplication.Repository
{
    public class Tempuser
    {
        public long Id { get; set; }
        public string Username { get; set; }
        public string linkedinUrl { get; set; }
        public DateTime? reg_datetime { get; set; }
        public long? regcode { get; set; }
        public int? yearsOfExp { get; set; }
        
        public bool? active { get; set; }
    }
}
