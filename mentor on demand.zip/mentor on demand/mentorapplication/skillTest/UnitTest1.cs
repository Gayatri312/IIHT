using mentorapplication.Controllers;
using mentorapplication.Models;
using NUnit.Framework;
using System.Collections.Generic;

namespace Tests
{
    public class Tests
    {
        [SetUp]
        public void Setup()
        {
        }

        [Test]
        public void GetmentorSkillsCorrect()
        {
            //var testProducts = GetTestProducts();
            var controller = new UserController();

            var result = controller.GetMentorSkills() as List<MentorSkills>;
            Assert.AreEqual(5, result.Count);
        }
        [Test]
        public void GetmentorSkillsIncorrect()
        {
            //var testProducts = GetTestProducts();
            var controller = new UserController();

            var result = controller.GetMentorSkills() as List<MentorSkills>;
            Assert.AreEqual(7, result.Count);
        }
    
}
}