export interface Itrainings
{
    id?:number;
    userId?:number;
    mentorId?:number;
    skillId?:number;
    status?:string;
    progress?:string;
    rating?:number;
    startDate?:Date;
    endDate?:Date;
    amountReceived?:number;
    techname?:string;
    username?:string;
    mentorname?:string;
}