export interface IUser 
{
id?:number;
username?:string;
password?:string; 
firstname?:string;
lastname?:string;
contactNumber?:number;
regDatetime?:Date;
regCode?:number;
forceResetPassword?:boolean;
active?:boolean;

}