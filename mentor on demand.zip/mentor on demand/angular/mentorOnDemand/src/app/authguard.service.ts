import { Injectable } from '@angular/core';
import { Router, ActivatedRouteSnapshot } from '@angular/router';
import { AuthService } from './auth.service';

@Injectable({
  providedIn: 'root'
})
export class AuthguardService {
  isLoggedIn = false;

  constructor(private route:Router,private auth:AuthService) { }


  canActivate(route: ActivatedRouteSnapshot): boolean{        
    this.isLoggedIn = this.auth.loggedIn;
    console.log("isLoggedIn: " + this.isLoggedIn);
    if(this.isLoggedIn){
        return true;
    }
    else{
        this.route.navigate(['login']);
        return false;
    }        
}
}
