export interface IAdmin
{
id?:number;
username?:string;
password?:string; 


}