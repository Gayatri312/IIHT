export interface ITech
{
id?:number;
name?:string;
toc?:string; 
duration?:number;
prerequites?:string; 


}