import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from '../user.service';
import { IUser } from '../IUser.module';
import { IMentor } from '../IMentor.Module';
import { IAdmin } from '../IAdmin.Module';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private route:Router,private user:UserService,private authservice:AuthService) { }

  userRole:number;
  userName:string;
  password:string;

  ngOnInit() {
  }

  selectrole()
  {{{debugger}}
    this.authservice.loginn();
    if(this.userRole==1)
    { {{debugger}}
      this.user.userlogin(this.userName,this.password).subscribe((result:IUser)=>  {
        console.log(result)

      
        {{debugger}}
        this.user.activeUser=result;
        this.user.GetTokenUser(this.userName);
    
        // this.route.navigate(['userdash']);
      });
      
    }
    else if(this.userRole==2)
    {
      
      this.user.userloginmentor(this.userName,this.password).subscribe((result:IMentor)=>  {
        console.log(result)
        

        this.user.activeUser1=result;
        this.user.GetTokenMentor(this.userName);
        // this.authservice.loginn();

      });
      // this.route.navigate(['mentordash']);

    }
    else if(this.userRole==3)
    {
      this.user.userloginadmin(this.userName,this.password).subscribe((result:IAdmin)=>  {
        console.log(result)
       
        this.user.activeUser2=result;
        this.user.GetTokenAdmin(this.userName);
        // this.authservice.loginn();

      });
      // this.route.navigate(['admindash']);
    }
  }

  }


