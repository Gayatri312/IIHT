import { Component, OnInit } from '@angular/core';
import { IMentor } from '../../IMentor.Module';
import { UserService } from '../../user.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-mentorreg',
  templateUrl: './mentorreg.component.html',
  styleUrls: ['./mentorreg.component.css']
})
export class MentorregComponent implements OnInit {

  constructor(private user:UserService,private route:Router) { }
  userr:IMentor={};
  showMsg: boolean = false;
  ngOnInit() {
  }
  register1()
  {
    this.user.mentorregistration(this.userr).subscribe();
    this.route.navigate(['login']);
    this.showMsg= true;
  }
  
}
