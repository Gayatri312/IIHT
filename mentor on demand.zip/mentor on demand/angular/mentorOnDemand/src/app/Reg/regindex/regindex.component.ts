import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-regindex',
  templateUrl: './regindex.component.html',
  styleUrls: ['./regindex.component.css']
})
export class RegindexComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
