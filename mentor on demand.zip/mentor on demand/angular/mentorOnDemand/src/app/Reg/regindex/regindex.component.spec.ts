import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RegindexComponent } from './regindex.component';

describe('RegindexComponent', () => {
  let component: RegindexComponent;
  let fixture: ComponentFixture<RegindexComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RegindexComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RegindexComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
