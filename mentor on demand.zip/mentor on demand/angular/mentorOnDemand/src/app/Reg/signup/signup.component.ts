import { Component, OnInit } from '@angular/core';
import { UserService } from '../../user.service';
import { Router } from '@angular/router';
import { IUser } from '../../IUser.module';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

  constructor(private user:UserService,private route:Router) { }
  userr:IUser={};

  ngOnInit() {
  }

register1()
{
  this.user.userregistation(this.userr).subscribe();
  this.route.navigate(['login']);
}

}
