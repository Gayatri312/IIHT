import { Injectable } from '@angular/core';
import { Route } from '@angular/compiler/src/core';
import { Router } from '@angular/router';

import { IUser } from './IUser.module';
import { HttpHandler, HttpHeaders, HttpClient } from '@angular/common/http';
import { IMentor } from './IMentor.Module';
import { IAdmin } from './IAdmin.Module';
import { ITech } from './ITech.Module';
import { IMentorSkills } from './IMentorSkills.Module';
import { AuthService } from './auth.service';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private route:Router,private http:HttpClient,private authservice:AuthService ) { }
activeUser:IUser={};
activeUser1:IMentor={};
activeUser2:IAdmin=null;
activeUser3:ITech=null;
activeUser4:IMentorSkills=null;
status:boolean=false;


  readonly rootURL='http://localhost:51042/api/User/'
  readonly rootURL1='http://localhost:51574/api/Mentor/'
  readonly rootURL2=' http://localhost:58041/api/'

 


  getMentorSkills()
  {{{debugger}}
     return this.http.get<IMentorSkills>(this.rootURL+'GetMentorSkills')
  }
  gettrainerlist()
  {
    return this.http.get<IMentor>(this.rootURL+'GetMentors')
  }
  gettechlist1()
  {
    return this.http.get<ITech>(this.rootURL+'GetSkills')
  }
  userregistation(User:IUser)
  {
    return this.http.post(this.rootURL+'InsertUserDetails/',User,{
      headers:new HttpHeaders({'content-Type':'application/json'})
    });
  }
  mentorregistration(User:IMentor)
  {
    return this.http.post(this.rootURL1+'InsertMentorDetails/',User,{
      headers:new HttpHeaders({'content-Type':'application/json'})
    });
  }
  userlogin(username:string,password:string)
  {
    {{debugger}}
  return this.http.get(this.rootURL+'login/'+username+'/'+password+'/')
  }

  GetTokenUser(username:string)
  

    {
      this.http.get(this.rootURL2+'Auth/GetUserToken/'+username).
      subscribe((res:any)=>{
        localStorage.setItem('token2',res.token);
        console.log(res.token);
        this.route.navigateByUrl('userdash');
      })
    
  }

  userloginmentor(username:string,password:string)
  {
    return this.http.get(this.rootURL+'loginmentor/'+username+'/'+password+'/')
  }
  GetTokenMentor(username:string)
  

    {
      this.http.get(this.rootURL2+'Auth/GetMentorToken/'+username).
      subscribe((res:any)=>{
        localStorage.setItem('token3',res.token);
        console.log(res.token);
    
        this.route.navigateByUrl('mentordash');
      })
    }
  


    userloginadmin(username:string,password:string)
    {
      return this.http.get(this.rootURL+'loginadmin/'+username+'/'+password+'/')
      }
      GetTokenAdmin(username:string)
      
      
        {
          this.http.get(this.rootURL2+'Auth/GetAdminToken/'+username).
          subscribe((res:any)=>{
            localStorage.setItem('token1',res.token);
            console.log(res.token);
            
            this.route.navigateByUrl('admindash');
          })
        
      }
    
    
}
