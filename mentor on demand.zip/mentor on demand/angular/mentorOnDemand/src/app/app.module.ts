import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import{FormsModule}  from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { DashboardComponent } from './Dash/dashboard/dashboard.component';
import { LoginComponent } from './login/login.component';
import { SignupComponent } from './Reg/signup/signup.component';
import { HttpClientModule } from '@angular/common/http';
import { MentorregComponent } from './Reg/mentorreg/mentorreg.component';
import { RegindexComponent } from './Reg/regindex/regindex.component';
import { AdmindashComponent } from './Dash/admindash/admindash.component';
import { MentordashComponent } from './Dash/mentordash/mentordash.component';
import { UserdashComponent } from './Dash/userdash/userdash.component';
import { CONTACTUSComponent } from './OTHERS/contactus/contactus.component';
import { ABOUTUSComponent } from './OTHERS/aboutus/aboutus.component';
import {NgxPaginationModule } from 'ngx-pagination';
import { AddskillsComponent } from './addskills/addskills.component'


@NgModule({
  declarations: [
    AppComponent,
    DashboardComponent,
    LoginComponent,
    SignupComponent,
    MentorregComponent,
    RegindexComponent,
    AdmindashComponent,
    MentordashComponent,
    UserdashComponent,
    CONTACTUSComponent,
    ABOUTUSComponent,
    AddskillsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    NgxPaginationModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
