import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DashboardComponent } from './Dash/dashboard/dashboard.component';
import { LoginComponent } from './login/login.component';
import { SignupComponent } from './Reg/signup/signup.component';
import { RegindexComponent } from './Reg/regindex/regindex.component';
import { MentorregComponent } from './Reg/mentorreg/mentorreg.component';
import { AdmindashComponent } from './Dash/admindash/admindash.component';
import { MentordashComponent } from './Dash/mentordash/mentordash.component';
import { UserdashComponent } from './Dash/userdash/userdash.component';
import { ABOUTUSComponent } from './OTHERS/aboutus/aboutus.component';
import { CONTACTUSComponent } from './OTHERS/contactus/contactus.component';
import { AddskillsComponent } from './addskills/addskills.component';
import { AuthguardService } from './authguard.service';




const routes: Routes = [

{path:'', redirectTo:'/dashboard',pathMatch:'full'},
{path:'dashboard', component: DashboardComponent },
{path:'login', component: LoginComponent },
{path:'signup', component: SignupComponent },
{path:'regindex', component: RegindexComponent  },
{path:'admindash', component: AdmindashComponent , canActivate:[AuthguardService]},
{path:'mentordash', component: MentordashComponent, canActivate:[AuthguardService] },
{path:'userdash', component: UserdashComponent  , canActivate:[AuthguardService]},
{path:'mentorreg', component: MentorregComponent},
{path:'aboutus', component: ABOUTUSComponent },
{path:'contactus', component: CONTACTUSComponent },
{path:'addskills', component: AddskillsComponent , canActivate:[AuthguardService] }





];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
