import { Component, OnInit } from '@angular/core';
import { MentorService } from '../mentor.service';
import { Router } from '@angular/router';
import { IMentorSkills } from '../IMentorSkills.Module';
import { UserService } from '../user.service';
import { ITech } from '../ITech.Module';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-addskills',
  templateUrl: './addskills.component.html',
  styleUrls: ['./addskills.component.css']
})
export class AddskillsComponent implements OnInit {

  constructor(private mentor:MentorService,private user:UserService,private route:Router,private auth:AuthService) { }
  mentorskills2:IMentorSkills={};
  skill:ITech[]=[];


  ngOnInit() {
    this.getskill();
  }


  addskill(mentorskills1:IMentorSkills)
  {
    this.mentorskills2.mid=this.user.activeUser1.id;
    this.mentor.addnewskill(mentorskills1).subscribe();
    this.route.navigate(['mentordash']);
  }
  logout(){
    this.auth.logOut();
    this.route.navigate(['/login'])
    
  }
  getskill()
  {
    {{debugger}}
    this.user.gettechlist1().subscribe(result=>{this.skill=result as ITech[], console.log(this.skill)});
     
  }


}
