export interface IMentorSkills 
{
id?:number;
mid?:number;
sid?:number;
selfRating?:number;
yearsOfExp?:number;
trainingsDelivered?:number;
facilitiesOffered?:number;


}