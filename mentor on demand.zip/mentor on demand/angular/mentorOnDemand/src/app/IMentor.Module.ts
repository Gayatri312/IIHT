export interface IMentor
{
id?:number;
username?:string;
password?:string; 
linkedinUrl?:string;
reg_datetime?:Date;
regcode?:number;
yearsOfExp?:number;
active?:boolean;

}