import { Component, OnInit } from '@angular/core';
import { UserService } from 'src/app/user.service';
import { IMentor } from 'src/app/IMentor.Module';
import { ITech } from 'src/app/ITech.Module';
import { IMentorSkills } from 'src/app/IMentorSkills.Module';
import { Itrainings } from 'src/app/Itrainings.Module';
import { MentorService } from 'src/app/mentor.service';
import { AuthService } from 'src/app/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-userdash',
  templateUrl: './userdash.component.html',
  styleUrls: ['./userdash.component.css']
})
export class UserdashComponent implements OnInit {

  constructor(private user:UserService,private mentor:MentorService,private auth:AuthService,private router:Router ) { }
mentors:IMentor[];

filteredMentors:IMentor[];
searchKey:string="";
skillid:number;
mentorid:number[];
skill:ITech[];
mentorskill:IMentorSkills[];
tech:ITech={};
id:number;
training:Itrainings={};
flag:boolean;
  ngOnInit() {

this.gettrainerlist();
this.filteredMentors=this.mentors;}
logout(){
  this.auth.logOut();
  this.router.navigate(['/login'])
  
}

  gettrainerlist()
  {{{debugger}}
    this.user.gettrainerlist().subscribe(result=>{this.mentors=result as IMentor[],this.filteredMentors=result as IMentor[],this.gettechlist1()});
  }
  gettechlist1()
  {
    this.user.gettechlist1().subscribe(result=>{this.skill=result as ITech[],this.getMentorSkills()});
  }
  getMentorSkills()
  {
this.user.getMentorSkills().subscribe(result=>{this.mentorskill=result as IMentorSkills[],
  console.log(this.mentors),console.log(this.skill),console.log(this.mentorskill)});
  }
  t1:ITech;
  t2:IMentorSkills[]=[]
  t3:IMentor[]=[];
  search():void{
    {{debugger}}
    if(this.searchKey=="")
    {
      this.filteredMentors=this.mentors;
    }
    else
    { 
      this.t1=this.skill.find(x=>x.name.toLowerCase().includes(this.searchKey.toLowerCase()))
      this.t2=this.mentorskill.filter(x=>x.sid==this.t1.id);
      for(let i of this.t2)
      {
        for(let j of this.mentors)
        {
          if(i.mid==j.id)
          {
            this.t3.push(j);
          }
        }
      }
      this.filteredMentors=this.t3;
      this.t3=[];

    }
   }
   nominate(mentor:IMentor)
   { {{debugger}}
   this.flag=true;
   this.id=mentor.id;
    this.tech=this.skill.find(x=>x.name.toLowerCase().includes(this.searchKey.toLowerCase()))
    this.training.skillId=this.tech.id;
    this.training.mentorId=mentor.id;
    this.training.userId=this.user.activeUser.id;
    this.training.status="sdf";
    this.training.progress="ere";
    this.training.rating=5;
    this.training.startDate=new Date(2019,11,2);
    this.training.endDate=new Date(2019,11,2);
    this.training.amountReceived=5000;
    this.mentor.addtrainings(this.training).subscribe();

  }
}
