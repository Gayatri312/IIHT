import { Component, OnInit } from '@angular/core';
import { Itrainings } from 'src/app/Itrainings.Module';
import { UserService } from 'src/app/user.service';
import { IUser } from 'src/app/IUser.module';
import { ITech } from 'src/app/ITech.Module';
import { IMentor } from 'src/app/IMentor.Module';
import { MentorService } from 'src/app/mentor.service';
import { AuthService } from 'src/app/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-mentordash',
  templateUrl: './mentordash.component.html',
  styleUrls: ['./mentordash.component.css']
})
export class MentordashComponent implements OnInit {

  constructor(private user: UserService, private mentor: MentorService,private auth:AuthService,private router:Router) { }
  training: Itrainings[];
  users: IUser[];
  skills: ITech[];
  temp: Itrainings = {};
  training1: Itrainings[] = [];
  mentors: IMentor[];
  ngOnInit() {
    this.getSkills();
  }
  getMentor() {
    { { debugger } }
    this.mentor.getmentors().subscribe(result => { this.mentors = result as IMentor[] });
  }
  logout(){
    this.auth.logOut();
    this.router.navigate(['/login'])
    
  }
  getSkills() {
    this.mentor.getskills().subscribe(result => { this.skills = result as ITech[], this.gettrainings() });
    console.log(this.skills)
  }
  gettrainings() {
    this.mentor.gettrainings().subscribe(result => { this.training = result as Itrainings[], this.getusers() });
  }
  getusers() {
    { { debugger } }
    this.mentor.getusers().subscribe(result => { this.users = result as IUser[], console.log(this.users), this.getnomination() });

  }



  getnomination() {
    { { debugger } }

    for (let i of this.training) {
      if (i.mentorId == this.user.activeUser1.id) {
        for (let j of this.users) {
          if (i.userId == j.id) {
            for (let k of this.skills) {
              if (i.skillId == k.id) {
                this.temp.mentorname = this.user.activeUser1.username;
                this.temp.username = j.username;
                this.temp.techname = k.name;
                this.temp.status = i.status;
                this.temp.rating = i.rating;
                this.temp.startDate = i.startDate;
                this.temp.endDate = i.endDate;
                this.temp.progress = i.progress;
                this.training1.push(this.temp);
              }
            }
          }
        }
      }
    }

  }


}
