import { Component, OnInit } from '@angular/core';
import { UserService } from 'src/app/user.service';
import { ITech } from 'src/app/ITech.Module';
import { AuthService } from 'src/app/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-admindash',
  templateUrl: './admindash.component.html',
  styleUrls: ['./admindash.component.css']
})
export class AdmindashComponent implements OnInit {

  constructor(private user:UserService,private auth:AuthService,private router:Router) { }
  tech:ITech[];

  ngOnInit() {
    this.user.gettechlist1().subscribe(result=>{this.tech=result as ITech[]})
  }
  logout(){
    this.auth.logOut();
    this.router.navigate(['/login'])
    
  }
}
