import { Injectable } from '@angular/core';
import { Itrainings } from './Itrainings.Module';
import { HttpHeaders } from '@angular/common/http';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { IMentorSkills } from './IMentorSkills.Module';

@Injectable({
  providedIn: 'root'
})
export class MentorService {

  constructor(private http:HttpClient,private route:Router) { }
  
  activeUser:IMentorSkills=null;
  readonly rootURL1='http://localhost:51574/api/Mentor/';
  readonly rootURL2=' http://localhost:51042/api/User/';
 


  getmentors()
{
  return this.http.get(this.rootURL1+'GetMentors/');
}
getskills()
{
  return this.http.get(this.rootURL1+'GetSkills/');
}
gettrainings()
{
  return this.http.get(this.rootURL1+'GetTrainings/');
}
getusers()
{
  return this.http.get(this.rootURL1+'GetUsers/');
}

addtrainings(training:Itrainings)
  
 {{{debugger}}
   return this.http.post('http://localhost:51574/api/Mentor/AddTrainings/',training,
   { headers:new HttpHeaders({'content-Type':'application/json'})
 });
 }



 addnewskill(mentorskill:IMentorSkills)
 {
   return this.http.post(this.rootURL2+'AddSkills/',mentorskill,
   { headers:new HttpHeaders({'content-Type':'application/json'})
 });

}
}

