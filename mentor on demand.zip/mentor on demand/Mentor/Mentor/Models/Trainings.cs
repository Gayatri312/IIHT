﻿using System;
using System.Collections.Generic;

namespace Mentor.Models
{
    public partial class Trainings
    {
        public long Id { get; set; }
        public long? UserId { get; set; }
        public long? MentorId { get; set; }
        public long? SkillId { get; set; }
        public string Status { get; set; }
        public string Progress { get; set; }
        public long? Rating { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public long? AmountReceived { get; set; }
    }
}
