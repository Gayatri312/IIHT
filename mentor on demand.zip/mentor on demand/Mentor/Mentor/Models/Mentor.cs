﻿using System;
using System.Collections.Generic;

namespace Mentor.Models
{
    public partial class Mentor
    {
        public long Id { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
        public string LinkedinUrl { get; set; }
        public DateTime? RegDatetime { get; set; }
        public long? RegCode { get; set; }
        public int? YearsOfExperience { get; set; }
        public bool? Active { get; set; }
    }
}
