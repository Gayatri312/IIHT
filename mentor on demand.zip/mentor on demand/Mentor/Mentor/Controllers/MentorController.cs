﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Mentor.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Mentor.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MentorController : ControllerBase
    {
        MentorOnDemandContext m = new MentorOnDemandContext();
        [HttpPost]
        [Route("InsertMentorDetails")]
        public void InsertMentorDetails([FromBody] Mentor.Models.Mentor mentor)
        {
            try
            {

                m.Database.ExecuteSqlCommand("MENTOR_REGISTRATION'" + mentor.Username +"','"+ mentor.Password +"','"+ mentor.LinkedinUrl +"','"+ mentor.RegDatetime +"',"+ mentor.RegCode +",'"+ mentor.YearsOfExperience +"',"+ mentor.Active);

            }
            catch (Exception e)
            {

            }
        }
        [HttpPost]
        [Route("AddTrainings")]
        public void addTrainings([FromBody] Trainings tr)
        {
            try
            {

                m.Trainings.Add(tr);
                m.SaveChanges();
            }
            catch (Exception e)
            {

            }
        }
        [HttpGet]
        [Route("GetSkills")]
        public IEnumerable<Skills> getskills()
        {
            List<Skills> li = m.Skills.ToList();
            return li;
        }
        [HttpGet]
        [Route("GetTrainings")]
        public IEnumerable<Trainings> GetTrainings()
        {
            try
            {
                List<Trainings> li = m.Trainings.ToList();
                return li;
            }
            catch (Exception e)
            {
                return null;
            }
        }
        [HttpGet]
        [Route("GetUsers")]
        public IEnumerable<Users> GetUsers()
        {
            try
            {
                List<Users> li = m.Users.ToList();
            return li;
            }
            catch (Exception e)
            {
                return null;
            }
        }
        [HttpGet]
        [Route("GetMentors")]
        public IEnumerable<Mentor.Models.Mentor> GetMentors()
        {
            try
            {
                List<Mentor.Models.Mentor> li = m.Mentor.ToList();
            return li;
            }
            catch (Exception e)
            {
                return null;
            }
        }


    }
}